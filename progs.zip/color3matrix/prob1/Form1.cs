﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prob1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string path1;

        private void button1_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog opDialog = new OpenFileDialog())
            {

                if (opDialog.ShowDialog() == DialogResult.OK)
                    try
                    {
                        String opPath = opDialog.FileName;

                        Bitmap p1 = new Bitmap(opPath);

                        path1 = opPath;

                        pictureBox1.Image = p1;
                    }
                    catch (Exception err)
                    {
                        MessageBox.Show("Something wrong with win1");
                    }

                
            }
        }

      
        private void button3_Click(object sender, EventArgs e)
        {
            ImageMatrix m1 = new ImageMatrix();
            int[,] matrix1 = m1.createMatrix(path1);
            

            using (Bitmap picture = new Bitmap(pictureBox1.Image)) 
            {
                //var wrap = new ImageWrapper();
                //int[,] wrapper = new int[picture.Height, picture.Width];
               
                //for (int i = 0; i < wrap.Width; i++)
                //{
                //    for (int j = 1; j < wrap.Height; j++)
                //    {
                //        int light1 = matrix1[i, j];
                       
                //        wrapper[i, j] = light1; //либо черное, либо белое.
                //    }
                //}

              

                    drawPicture(matrix1); //здесь должен быть результат
            }
        }

        private void drawPicture(int[,] wrapper)
        {
            int[] histogramm = new int[255];

            for (int i = 0; i < wrapper.GetLength(0); i++)
            {
                for (int j = 0; j < wrapper.GetLength(1); j++)
                {
                    histogramm[wrapper[i, j]]++;
                }
            }
          
            Bitmap g = new Bitmap(255, 500);
            for (int i = 0; i < histogramm.Length; i++)
            {

                for (int j = 0; j <= histogramm[i]; j++)
                {
                    if (j > 499) break;
                    g.SetPixel(i, j, Color.Black);
                }
               
            }
            g.RotateFlip(RotateFlipType.Rotate180FlipNone);
            pictureBox3.Image = g;
        }

    }
}
