﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prob1
{
    class ImageWrapper
    {
        public int Height;
        public int Width;
        
        public System.Drawing.Color[,]  createWrapper(System.Drawing.Bitmap picture, bool trueWAT)
        {
            System.Drawing.Color[,] colors = new System.Drawing.Color[picture.Width, picture.Height];

            for (int i = 0; i < picture.Width; i++)
            {
                for (int j = 0; j < picture.Height; j++)
                // = picture.GetPixel;
                {
                    colors[i, j] = picture.GetPixel(i, j);
                }
            }

            Height = picture.Height;
            Width = picture.Width;

            return colors;
        }

        public System.Drawing.Color[,] createWrapper(System.Drawing.Bitmap picture)
        {
            System.Drawing.Color[,] colors = new System.Drawing.Color[picture.Width, picture.Height];

            Height = picture.Height;
            Width = picture.Width;

            return colors;
        }

    }
}
