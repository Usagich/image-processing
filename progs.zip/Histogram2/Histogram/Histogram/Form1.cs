﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Histogram
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Bitmap img = new Bitmap("lena.jpg");
            pictureBox1.Image = img;
            GetHistogram(img);


        }

        public void GetHistogram(Bitmap image)
        {
            Bitmap diagram = new Bitmap(256,512);
            int[] histogram = new int[255];

            for (int i = 0; i < image.Width; i++)
            {
                for (int j = 0; j < image.Height; j++)
                {
                    int br = Convert.ToInt16(image.GetPixel(i, j).GetBrightness() * 100);
                    histogram[br]++;
                }
            }

            for (int i = 0; i < 255; i++)
            {
                for (int j = 0; j < histogram[i]; j++)
                {
                    diagram.SetPixel(i, j / 100, Color.Black);
                }
            }


            diagram.RotateFlip(RotateFlipType.Rotate180FlipNone);
            pictureBox2.Image = diagram;
        }

        public void BrightnessDown(Bitmap image)
        {
            Bitmap res = new Bitmap(image.Width, image.Height);
            for (int i = 0; i < image.Width; i++)
            {
                for (int j = 0; j < image.Height; j++)
                {
                    int red = image.GetPixel(i, j).R;
                    int green = image.GetPixel(i, j).G;
                    int blue = image.GetPixel(i, j).B;

                    if (red - 10 >= 0 && blue - 10 >= 0 && green - 10 >= 0)
                    {
                        red -= 10;
                        green -= 10;
                        blue -= 10;
                    }

                    Color c = Color.FromArgb(red, green, blue);

                    res.SetPixel(i, j,c);
                }
                
            }
            pictureBox1.Image = res;
           
        }


        public void BrightnessUp(Bitmap image)
        {
            Bitmap res = new Bitmap(image.Width, image.Height);
            for (int i = 0; i < image.Width; i++)
            {
                for (int j = 0; j < image.Height; j++)
                {
                    int red = image.GetPixel(i, j).R;
                    int green = image.GetPixel(i, j).G;
                    int blue = image.GetPixel(i, j).B;

                    if (red + 10 <= 255 && blue + 10 <= 255 && green + 10 <= 255)
                    {
                        red += 10;
                        green += 10;
                        blue += 10;
                    }

                    Color c = Color.FromArgb(red, green, blue);

                    res.SetPixel(i, j, c);
                }

            }
            pictureBox1.Image = res;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            BrightnessDown(new Bitmap(pictureBox1.Image));
            GetHistogram(new Bitmap(pictureBox1.Image));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            BrightnessUp(new Bitmap(pictureBox1.Image));
            GetHistogram(new Bitmap(pictureBox1.Image));
        }
    }
}
