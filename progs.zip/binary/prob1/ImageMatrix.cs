﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prob1
{
    class ImageMatrix
    {

        int height, width;
        System.Drawing.Bitmap picture;

        public int[,] createMatrix(string file_name)
        {
            int[,] res;

            using ( System.Drawing.Bitmap picture = new System.Drawing.Bitmap(file_name))
            {
                var wrap = new ImageWrapper();
                System.Drawing.Color[,] wrapper = wrap.createWrapper(picture, true);

                res = new int[picture.Width, picture.Height];  
                for (int i = 0; i < wrap.Width; i++)
                {
                    for (int j = 0; j < wrap.Height; j++)
                    {
                        System.Drawing.Color color = wrapper[i, j];
                        if (((color.R + color.G + color.B) / 3) < 120)
                            res[i, j] = 1;
                        else
                            res[i, j] = 0;
                    } 
                }

                height = wrap.Height;   
                width = wrap.Width;
                this.picture = picture;

            }

     
            return res;
        }

    }


}
