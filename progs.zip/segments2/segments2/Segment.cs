﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace segments2
{
    class Segment
    {
        public int metkas; //текущая метка
        public int colorMin;   //нижний порог цвета для сегмента
        public int colorMax;   //верхний порог цвета для сегмента

        int[,] coords; //матрица координат размещения пикселей сегмента

        static Segment()
        {
           // metkas = 0;
            
        }

        Segment(int posI, int posJ, int metkas)
        { 
        
        }



    }
}
