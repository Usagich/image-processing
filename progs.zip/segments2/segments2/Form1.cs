﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using segments2;


namespace Histogram
{
    public partial class Form1 : Form
    {
        public string path1;
        Bitmap segmentsOut;

        System.Diagnostics.Stopwatch t1 = new System.Diagnostics.Stopwatch();
        System.Diagnostics.Stopwatch t2 = new System.Diagnostics.Stopwatch();
        System.Diagnostics.Stopwatch t3 = new System.Diagnostics.Stopwatch();
        

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog opDialog = new OpenFileDialog())
            {
                if (opDialog.ShowDialog() == DialogResult.OK)
                    try
                    {
                        String opPath = opDialog.FileName;

                        Bitmap p1 = new Bitmap(opPath);

                        path1 = opPath;
                        
                        pictureBox1.Image = p1;

                        GetHistogram(p1);
                    }
                    catch (Exception err)
                    {
                        MessageBox.Show("Something wrong with win1");
                    }
            }
        }

        public void GetHistogram(Bitmap image)
        {
            t1.Start();
            
            Bitmap diagram = new Bitmap(100, 255);
            int[] histogram = new int[100];
            int temp =0;
            try
            {
                for (int i = 0; i < image.Width; i++)
                {
                    for (int j = 0; j < image.Height; j++)
                    {
                        int br = Convert.ToInt16(image.GetPixel(i, j).GetBrightness() * 100);
                        if (br != 100)
                            histogram[br]++;
                        else
                            histogram[99]++;
                        temp = br;

                    }
                }
                
            }
            catch (Exception err) 
            {
                MessageBox.Show(err.ToString() + " br =" + temp); 
            }

           
                for (int i = 0; i < histogram.Length; i++)
                {
                    for (int j = 0; j < histogram[i]; j++)
                    { 
                        try
                        {
                            if (j / 100 < 254)
                                diagram.SetPixel(i, j / 100, Color.Black);
                            else
                                break;
                        }
                        catch (Exception err)
                        {
                            MessageBox.Show(err.ToString() + " i= " + i + " j= " + j + " Value=" + histogram[i]);
                            break;
                        }
                    }
                }
           

            diagram.RotateFlip(RotateFlipType.Rotate180FlipNone);
            pictureBox2.Image = diagram;

            t1.Stop();

            TimeSpan ts = t1.Elapsed;

            // Format and display the TimeSpan value.
            string elapsedTime = String.Format("{0:00}:{1:00}:{2:00}.{3:00}",
                ts.Hours, ts.Minutes, ts.Seconds,
                ts.Milliseconds / 10);

            label3.Text = ts.ToString();

            t1.Reset();
        }


        public void GetSegments(Bitmap image)
        {
            t3.Start();

            segmentsOut = new Bitmap(image.Width, image.Height);//////
            int[] histogram = new int[255];
            
            int[,] filterValues = new int[3, 3];
            int[,] segmentsCheck = new int[image.Width, image.Height];

            for (int i = 1; i < image.Width - 2; i++)
            {
                for (int j = 1; j < image.Height - 2; j++)
                {
                    filterValues[0, 0] = Convert.ToInt16(image.GetPixel(i, j).GetBrightness() * 100);
                    filterValues[0, 1] = Convert.ToInt16(image.GetPixel(i, j + 1).GetBrightness() * 100);
                    filterValues[0, 2] = Convert.ToInt16(image.GetPixel(i, j + 2).GetBrightness() * 100);

                    filterValues[1, 0] = Convert.ToInt16(image.GetPixel(i + 1, j).GetBrightness() * 100);
                    filterValues[1, 1] = Convert.ToInt16(image.GetPixel(i + 1, j + 1).GetBrightness() * 100);
                    filterValues[1, 2] = Convert.ToInt16(image.GetPixel(i + 1, j + 2).GetBrightness() * 100);

                    filterValues[2, 0] = Convert.ToInt16(image.GetPixel(i + 2, j).GetBrightness() * 100);
                    filterValues[2, 1] = Convert.ToInt16(image.GetPixel(i + 2, j + 1).GetBrightness() * 100);
                    filterValues[2, 2] = Convert.ToInt16(image.GetPixel(i + 2, j + 2).GetBrightness() * 100);

                   

                    if ((filterValues[1, 1] - filterValues[0, 0]) < 20)
                    {
                        if (segmentsCheck[i + 1, j + 1] == 0)
                        {
                            if ((filterValues[1, 1] > 20) && (filterValues[1, 1] <= 40))
                            {
                                segmentsCheck[i, j] = 1;
                                segmentsCheck[i + 1, j + 1] = 1;
                            }
                            else if ((filterValues[1, 1] > 40) && (filterValues[1, 1] <= 60))
                            {
                                segmentsCheck[i, j] = 2;
                                segmentsCheck[i + 1, j + 1] = 2;
                            }
                            else if ((filterValues[1, 1] > 60) && (filterValues[1, 1] <= 80))
                            {
                                segmentsCheck[i, j] = 3;
                                segmentsCheck[i + 1, j + 1] = 3;
                            }
                            else if ((filterValues[1, 1] > 80) && (filterValues[1, 1] <= 100))
                            {
                                segmentsCheck[i, j] = 4;
                                segmentsCheck[i + 1, j + 1] = 4;
                            }
                        }

                    }
                    if ((filterValues[1, 1] - filterValues[0, 1]) < 20)
                    {
                        if (segmentsCheck[i + 1, j + 1] == 0)
                        {
                            if ((filterValues[1, 1] > 20) && (filterValues[1, 1] <= 40))
                            {
                                segmentsCheck[i, j + 1] = 1;
                                segmentsCheck[i + 1, j + 1] = 1;
                            }
                            else if ((filterValues[1, 1] > 40) && (filterValues[1, 1] <= 60))
                            {
                                segmentsCheck[i, j + 1] = 2;
                                segmentsCheck[i + 1, j + 1] = 2;
                            }
                            else if ((filterValues[1, 1] > 60) && (filterValues[1, 1] <= 80))
                            {
                                segmentsCheck[i, j + 1] = 3;
                                segmentsCheck[i + 1, j + 1] = 3;
                            }
                            else if ((filterValues[1, 1] > 80) && (filterValues[1, 1] <= 100))
                            {
                                segmentsCheck[i, j + 1] = 4;
                                segmentsCheck[i + 1, j + 1] = 4;
                            }
                        }
                    }
                    if ((filterValues[1, 1] - filterValues[0, 2]) < 20)
                    {
                        if (segmentsCheck[i + 1, j + 1] == 0)
                        {
                            if ((filterValues[1, 1] > 20) && (filterValues[1, 1] <= 40))
                            {
                                segmentsCheck[i, j + 2] = 1;
                                segmentsCheck[i + 1, j + 1] = 1;
                            }
                            else if ((filterValues[1, 1] > 40) && (filterValues[1, 1] <= 60))
                            {
                                segmentsCheck[i, j + 2] = 2;
                                segmentsCheck[i + 1, j + 1] = 2;
                            }
                            else if ((filterValues[1, 1] > 60) && (filterValues[1, 1] <= 80))
                            {
                                segmentsCheck[i, j + 2] = 3;
                                segmentsCheck[i + 1, j + 1] = 3;
                            }
                            else if ((filterValues[1, 1] > 80) && (filterValues[1, 1] <= 100))
                            {
                                segmentsCheck[i, j + 2] = 4;
                                segmentsCheck[i + 1, j + 1] = 4;
                            }
                        }
                    }
                    if ((filterValues[1, 1] - filterValues[1, 0]) < 20)
                    {
                        if (segmentsCheck[i + 1, j + 1] == 0)
                        {
                            if ((filterValues[1, 1] > 20) && (filterValues[1, 1] <= 40))
                            {
                                segmentsCheck[i + 1, j] = 1;
                                segmentsCheck[i + 1, j + 1] = 1;
                            }
                            else if ((filterValues[1, 1] > 40) && (filterValues[1, 1] <= 60))
                            {
                                segmentsCheck[i + 1, j] = 2;
                                segmentsCheck[i + 1, j + 1] = 2;
                            }
                            else if ((filterValues[1, 1] > 60) && (filterValues[1, 1] <= 80))
                            {
                                segmentsCheck[i + 1, j] = 3;
                                segmentsCheck[i + 1, j + 1] = 3;
                            }
                            else if ((filterValues[1, 1] > 80) && (filterValues[1, 1] <= 100))
                            {
                                segmentsCheck[i + 1, j] = 4;
                                segmentsCheck[i + 1, j + 1] = 4;
                            }
                        }
                    }
                    if ((filterValues[1, 1] - filterValues[1, 2]) < 20)
                    {
                        if (segmentsCheck[i + 1, j + 1] == 0)
                        {
                            if ((filterValues[1, 1] > 20) && (filterValues[1, 1] <= 40))
                            {
                                segmentsCheck[i + 1, j + 2] = 1;
                                segmentsCheck[i + 1, j + 1] = 1;
                            }
                            else if ((filterValues[1, 1] > 40) && (filterValues[1, 1] <= 60))
                            {
                                segmentsCheck[i + 1, j + 2] = 2;
                                segmentsCheck[i + 1, j + 1] = 2;
                            }
                            else if ((filterValues[1, 1] > 60) && (filterValues[1, 1] <= 80))
                            {
                                segmentsCheck[i + 1, j + 2] = 3;
                                segmentsCheck[i + 1, j + 1] = 3;
                            }
                            else if ((filterValues[1, 1] > 80) && (filterValues[1, 1] <= 100))
                            {
                                segmentsCheck[i + 1, j + 2] = 4;
                                segmentsCheck[i + 1, j + 1] = 4;
                            }
                        }
                    }
                    if ((filterValues[1, 1] - filterValues[2, 0]) < 20)
                    {
                        if (segmentsCheck[i + 1, j + 1] == 0)
                        {
                            if ((filterValues[1, 1] > 20) && (filterValues[1, 1] <= 40))
                            {
                                segmentsCheck[i + 2, j] = 1;
                                segmentsCheck[i + 1, j + 1] = 1;
                            }
                            else if ((filterValues[1, 1] > 40) && (filterValues[1, 1] <= 60))
                            {
                                segmentsCheck[i + 2, j] = 2;
                                segmentsCheck[i + 1, j + 1] = 2;
                            }
                            else if ((filterValues[1, 1] > 60) && (filterValues[1, 1] <= 80))
                            {
                                segmentsCheck[i + 2, j] = 3;
                                segmentsCheck[i + 1, j + 1] = 3;
                            }
                            else if ((filterValues[1, 1] > 80) && (filterValues[1, 1] <= 100))
                            {
                                segmentsCheck[i + 2, j] = 4;
                                segmentsCheck[i + 1, j + 1] = 4;
                            }
                        }
                    }
                    if ((filterValues[1, 1] - filterValues[2, 1]) < 20)
                    {
                        if (segmentsCheck[i + 1, j + 1] == 0)
                        {
                            if ((filterValues[1, 1] > 20) && (filterValues[1, 1] <= 40))
                            {
                                segmentsCheck[i + 2, j + 1] = 1;
                                segmentsCheck[i + 1, j + 1] = 1;
                            }
                            else if ((filterValues[1, 1] > 40) && (filterValues[1, 1] <= 60))
                            {
                                segmentsCheck[i + 2, j + 1] = 2;
                                segmentsCheck[i + 1, j + 1] = 2;
                            }
                            else if ((filterValues[1, 1] > 60) && (filterValues[1, 1] <= 80))
                            {
                                segmentsCheck[i + 2, j + 1] = 3;
                                segmentsCheck[i + 1, j + 1] = 3;
                            }
                            else if ((filterValues[1, 1] > 80) && (filterValues[1, 1] <= 100))
                            {
                                segmentsCheck[i + 2, j + 1] = 4;
                                segmentsCheck[i + 1, j + 1] = 4;
                            }
                        }
                    }
                    if ((filterValues[1, 1] - filterValues[2, 2]) < 20)
                    {
                        if (segmentsCheck[i + 1, j + 1] == 0)
                        {
                            if ((filterValues[1, 1] > 20) && (filterValues[1, 1] <= 40))
                            {
                                segmentsCheck[i + 2, j + 2] = 1;
                                segmentsCheck[i + 1, j + 1] = 1;
                            }
                            else if ((filterValues[1, 1] > 40) && (filterValues[1, 1] <= 60))
                            {
                                segmentsCheck[i + 2, j + 2] = 2;
                                segmentsCheck[i + 1, j + 1] = 2;
                            }
                            else if ((filterValues[1, 1] > 60) && (filterValues[1, 1] <= 80))
                            {
                                segmentsCheck[i + 2, j + 2] = 3;
                                segmentsCheck[i + 1, j + 1] = 3;
                            }
                            else if ((filterValues[1, 1] > 80) && (filterValues[1, 1] <= 100))
                            {
                                segmentsCheck[i + 2, j + 2] = 4;
                                segmentsCheck[i + 1, j + 1] = 4;
                            }
                        }
                    }

                }
            }


            for (int i = 0; i < image.Width; i++)
            {
                for (int j = 0; j < image.Height; j++)
                {
                    switch (segmentsCheck[i, j])
                    {
                        case 0:
                        {
                            segmentsOut.SetPixel(i, j, Color.Black);
                            break;
                        }
                        case 1:
                        {
                            segmentsOut.SetPixel(i, j, Color.Aqua);
                            break;
                        }
                        case 2:
                        {
                            segmentsOut.SetPixel(i, j, Color.Beige);
                            break;
                        }
                        case 3:
                        {
                            segmentsOut.SetPixel(i, j, Color.Chocolate);
                            break;
                        }
                        case 4:
                        {
                            segmentsOut.SetPixel(i, j, Color.Coral);
                            break;
                        }
                    }
                }
            }

            pictureBox3.Image = segmentsOut;

            t3.Stop();

            TimeSpan ts = t3.Elapsed;

            // Format and display the TimeSpan value.
            string elapsedTime = String.Format("{0:00}:{1:00}:{2:00}.{3:00}",
                ts.Hours, ts.Minutes, ts.Seconds,
                ts.Milliseconds / 10);

            label4.Text = ts.ToString();
            t3.Reset();
          
        }

        public void BrightnessDown(Bitmap image)
        {
            Bitmap res = new Bitmap(image.Width, image.Height);
            for (int i = 0; i < image.Width; i++)
            {
                for (int j = 0; j < image.Height; j++)
                {
                    int red = image.GetPixel(i, j).R;
                    int green = image.GetPixel(i, j).G;
                    int blue = image.GetPixel(i, j).B;

                    if (red - 10 >= 0 && blue - 10 >= 0 && green - 10 >= 0)
                    {
                        red -= 10;
                        green -= 10;
                        blue -= 10;
                    }

                    Color c = Color.FromArgb(red, green, blue);

                    res.SetPixel(i, j, c);
                }

            }
            pictureBox1.Image = res;

        }


        public void BrightnessUp(Bitmap image)
        {
            Bitmap res = new Bitmap(image.Width, image.Height);
            for (int i = 0; i < image.Width; i++)
            {
                for (int j = 0; j < image.Height; j++)
                {
                    int red = image.GetPixel(i, j).R;
                    int green = image.GetPixel(i, j).G;
                    int blue = image.GetPixel(i, j).B;

                    if (red + 10 <= 255 && blue + 10 <= 255 && green + 10 <= 255)
                    {
                        red += 10;
                        green += 10;
                        blue += 10;
                    }

                    Color c = Color.FromArgb(red, green, blue);

                    res.SetPixel(i, j, c);
                }

            }
            pictureBox1.Image = res;

        }

        private void button2_Click(object sender, EventArgs e)
        {
            t2.Start();

            BrightnessDown(new Bitmap(pictureBox1.Image));
            GetHistogram(new Bitmap(pictureBox1.Image));

            t2.Stop();

            TimeSpan ts = t2.Elapsed;

            // Format and display the TimeSpan value.
            string elapsedTime = String.Format("{0:00}:{1:00}:{2:00}.{3:00}",
                ts.Hours, ts.Minutes, ts.Seconds,
                ts.Milliseconds / 10);

            label5.Text = ts.ToString();
            t2.Reset();

            GetSegments(new Bitmap(pictureBox1.Image));
        }

        private void button3_Click(object sender, EventArgs e)
        {
            t2.Start();

            BrightnessUp(new Bitmap(pictureBox1.Image));
            GetHistogram(new Bitmap(pictureBox1.Image));

            t2.Stop();

            TimeSpan ts = t2.Elapsed;

            // Format and display the TimeSpan value.
            string elapsedTime = String.Format("{0:00}:{1:00}:{2:00}.{3:00}",
                ts.Hours, ts.Minutes, ts.Seconds,
                ts.Milliseconds / 10);

            label5.Text = ts.ToString();

            GetSegments(new Bitmap(pictureBox1.Image));
        }

        private void gsButton_Click(object sender, EventArgs e)
        {
            GetSegments(new Bitmap(pictureBox1.Image));
        }

        public void GetContoursFromMatrix(int[,] segmentsMatrix)
        {
            int[,] filterValues = new int[3, 3];
            //int[] contour;
           //int[,] segmentsCheck = new int[image.Width, image.Height];

            for (int i = 1; i < segmentsMatrix.GetLength(0) - 2; i++)
            {
                for (int j = 1; j < segmentsMatrix.GetLength(1) - 2; j++)
                {
                    filterValues[0, 0] = segmentsMatrix[i, j];
                    filterValues[0, 1] = segmentsMatrix[i, j + 1];
                    filterValues[0, 2] = segmentsMatrix[i, j + 2];

                    filterValues[1, 0] = segmentsMatrix[i + 1, j];
                    filterValues[1, 1] = segmentsMatrix[i + 1, j + 1];
                    filterValues[1, 2] = segmentsMatrix[i + 1, j + 2];

                    filterValues[2, 0] = segmentsMatrix[i + 2, j];
                    filterValues[2, 1] = segmentsMatrix[i + 2, j + 1];
                    filterValues[2, 2] = segmentsMatrix[i + 2, j + 2];

                }
            }

            //segmentsOut.RotateFlip(RotateFlipType.Rotate180FlipNone); //IDN is it needed
           // pictureBox3.Image = segmentsOut;
            //segmentsOut.Save(path1 + ".bmp");
        }

        public void GetContoursFromImage(int[,] segmentsMatrix)
        { }

        private void button2_Click_1(object sender, EventArgs e)
        {
            segmentsOut.Save(path1 + ".png");
        }


    }
}
