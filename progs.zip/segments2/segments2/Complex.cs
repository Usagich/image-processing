﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace segments2
{
    class Complex
    {
        int real;
        int imagin;
        //vector

        Complex()
        {
            this.real = 0;
            this.imagin = 0;
        }

        Complex(string s)
        { 
            string[] temp = s.Split('-', '+', ' ', 'i', 'j');
            this.real = Convert.ToInt32(temp[0]);
            this.imagin = Convert.ToInt32(temp[1]);
        }

        Complex(int real, int imagin)
        {
            this.real = real;
            this.imagin = imagin;
        }

        Complex(double real, double imagin)
        {
            this.real = Convert.ToInt32(real);
            this.imagin = Convert.ToInt32(imagin);
        }

        void set(int real, int imagin) 
        { 
            this.real = real;
            this.imagin = imagin;
        }
        int[] get() 
        {
            int[] num = new int [2];
            num[0] = this.real;
            num[1] = this.imagin;
            return num;
        }

        public static bool operator ==(Complex a, Complex b)
        {

            if (((a.real == b.real) || (a.real - 2 == b.real) || (a.real - 1 == b.real) || (a.real == b.real - 2) || (a.real == b.real - 1))
                && ((a.imagin == b.imagin) || (a.imagin - 2 == b.imagin) || (a.imagin - 1 == b.imagin) || (a.imagin == b.imagin - 2) || (a.imagin == b.imagin - 1)))
                return true;
            else
                return false;

        }


        public static bool operator !=(Complex a, Complex b)
        {

            if (((a.real == b.real) || (a.real - 2 == b.real) || (a.real - 1 == b.real) || (a.real == b.real - 2) || (a.real == b.real - 1))
                && ((a.imagin == b.imagin) || (a.imagin - 2 == b.imagin) || (a.imagin - 1 == b.imagin) || (a.imagin == b.imagin - 2) || (a.imagin == b.imagin - 1)))
                return false;
            else
                return true;

        }
    }
}
