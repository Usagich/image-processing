﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prob1
{
    class ImageMatrix
    {

        int height, width;
        System.Drawing.Bitmap picture;

        public int[,] createMatrix(string file_name)
        {
            int[,] res;

            using ( System.Drawing.Bitmap picture = new System.Drawing.Bitmap(file_name))
            {
                var wrap = new ImageWrapper();
                System.Drawing.Color[,] wrapper = wrap.createWrapper(picture, true);

                res = new int[picture.Width, picture.Height];  
                for (int i = 0; i < wrap.Width; i++)
                {
                    for (int j = 0; j < wrap.Height; j++)
                    {
                        System.Drawing.Color color = wrapper[i, j];
                        res[i, j] = (color.R + color.G + color.B) / 3; //просто ищем сдвиг, пофиг на цвет. в итоге будет либо черный, либо белый (после обработки лайт)
                    } //мне кажется, лучше брать сумму цвета, так меньше вероятность совпадения при разных значениях. но нужно подумать как потом обработать в переменной Лайт
                }

                height = wrap.Height;   /* потом добавим нормальную реализацию в класс ImageMatrix */
                width = wrap.Width;
                this.picture = picture;

            }

     
            return res;
        }

    }


}
