﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prob1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        string path1, path2;

        private void button1_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog opDialog = new OpenFileDialog())
            {

                if (opDialog.ShowDialog() == DialogResult.OK)
                    try
                    {
                        String opPath = opDialog.FileName;

                        Bitmap p1 = new Bitmap(opPath);

                        path1 = opPath;

                        pictureBox1.Image = p1;
                    }
                    catch (Exception err)
                    {
                        MessageBox.Show("Something wrong with win1");
                    }

                
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog opDialog = new OpenFileDialog())
            {

                if (opDialog.ShowDialog() == DialogResult.OK)
                    try
                    {
                        String opPath = opDialog.FileName;

                        Bitmap p2 = new Bitmap(opPath);

                        path2 = opPath;

                        pictureBox2.Image = p2;
                    }
                    catch (Exception err)
                    {
                        MessageBox.Show("Something wrong with win2");
                    }

                
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ImageMatrix m1 = new ImageMatrix();
            int[,] matrix1 = m1.createMatrix(path1);
            ImageMatrix m2 = new ImageMatrix();
            int[,] matrix2 = m2.createMatrix(path2);

            

            using (Bitmap picture = new Bitmap(pictureBox1.Image)) 
            {
                var wrap = new ImageWrapper();
                Color[,] wrapper = wrap.createWrapper(picture);
                for (int i = 0; i < wrap.Width; i++)
                {
                    for (int j = 1; j < wrap.Height; j++)
                    {
                        int light1 = matrix1[i, j];
                        int light2 = matrix2[i, j];
                        int light = Math.Abs(light2 - light1);
                        if (light < 50) 
                            light = 0; 
                        else 
                            light = 255;
                        wrapper[i, j] = Color.FromArgb(light, light, light); //либо черное, либо белое.
                    }
                }
           
                    drawPicture(wrapper, wrap); //здесь должен быть результат
            }
        }

        private void drawPicture(Color[,] wrapper, ImageWrapper wrap)
        {
            Bitmap g = new Bitmap(wrapper.GetLength(0), wrapper.GetLength(1));

            for (int i = 0; i < wrap.Width; i++)
            {
                for (int j = 0; j < wrap.Height; j++)
                {
                    if (wrapper[i, j] == Color.FromArgb(255, 255, 255, 255))
                        g.SetPixel(i, j, Color.White);
                    else
                        g.SetPixel(i, j, Color.Black);
                }
            }
            pictureBox3.Image = g;
        }

    }
}
